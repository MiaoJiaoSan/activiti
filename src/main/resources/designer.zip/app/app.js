import $, { type } from 'jquery';
import BpmnModeler from 'bpmn-js/lib/Modeler';
import propertiesPanelModule from './workflow/properties-panel';
import propertiesProviderModule from './workflow/properties-panel/provider/activiti';
import activitiModdleDescriptor from '../resources/activiti.json';
import customTranslate from './workflow/customTranslate/customTranslate';
import customControlsModule from './workflow/customControls';
// require modeler   
// from '..node_modules/modeler'
import {
  debounce
} from 'min-dash';
import diagramXML from '../resources/newDiagram.bpmn';
var container = $('#js-drop-zone');
var canvas = $('#js-canvas');
var customTranslateModule = {
    translate: [ 'value', customTranslate ]
};
var bpmnModeler = new BpmnModeler({
  container: canvas,
  propertiesPanel: {
    parent: '#js-properties-panel'
  },
  //添加属性面板，添加翻译
  additionalModules: [
    propertiesPanelModule,
    propertiesProviderModule,
      customTranslateModule,
      customControlsModule

  ],
    //模块拓展，拓展activiti的描述
  moddleExtensions: {
    activiti: activitiModdleDescriptor
  }
});
container.removeClass('with-diagram');

function createNewDiagram() {
  openDiagram(diagramXML);
}

function openDiagram(xml) {

  bpmnModeler.importXML(xml, function(err) {

    if (err) {
      container
        .removeClass('with-diagram')
        .addClass('with-error');

      container.find('.error pre').text(err.message);

      console.error(err);
    } else {
      container
        .removeClass('with-error')
        .addClass('with-diagram');
    }


  });
}

function saveSVG(done) {
  bpmnModeler.saveSVG(done);
}

function download(done) {

  bpmnModeler.saveXML({ format: true }, function(err, xml) {
    done(err, xml);
  });
}

function submit(e) {
  e.stopPropagation();
  e.preventDefault();
  bpmnModeler.saveXML({ format: true }, function(err, xml) {
    console.log(xml);
    let id, name;
    try{
      let process = xml.match(/process\s*(.+)\s*>/)[1];
      id = process.match(/id="(.+?)"/)[1];
      name = process.match(/name="(.+?)"/)[1];
      if(!(id&&name)){
        throw new Error("属性错误");
      }
    }catch(e){
      alert(e);
      return;
    }
    $.ajax({
      url: 'http://admin:admin@localhost:8080/repository',
      type: 'POST',
      contentType: 'application/json;charset=UTF-8',
      dataType: 'json',
      data: JSON.stringify({
        xml:xml,
        key:id,
        name: name
      }),
      success:rst=>{
        alert(rst);
      }
    });
  });
}

function registerFileDrop(container, callback) {

  function handleFileSelect(e) {
    e.stopPropagation();
    e.preventDefault();

    var files = e.dataTransfer.files;

    var file = files[0];

    var reader = new FileReader();

    reader.onload = function(e) {

      var xml = e.target.result;

      callback(xml);
    };

    reader.readAsText(file);
  }

  function handleDragOver(e) {
    e.stopPropagation();
    e.preventDefault();

    e.dataTransfer.dropEffect = 'copy'; // Explicitly show this is a copy.
  }

  container.get(0).addEventListener('dragover', handleDragOver, false);
  container.get(0).addEventListener('drop', handleFileSelect, false);
}


////// file drag / drop ///////////////////////

// check file api availability
if (!window.FileList || !window.FileReader) {
  window.alert(
    'Looks like you use an older browser that does not support drag and drop. ' +
    'Try using Chrome, Firefox or the Internet Explorer > 10.');
} else {
  registerFileDrop(container, openDiagram);
}

// bootstrap diagram functions

$(function() {

  // createNewDiagram();
  $('.menu').on('click',function(e) {
    e.stopPropagation();
    e.preventDefault();
    let id = $(e.target).data('id');
    switch(id){
      case 'create':show(id,createNewDiagram) ; break;
      case 'process': show(id, ()=>{
        $.ajax({
          url:'http://admin:admin@localhost:8080/repository',
          type:'GET',
          data:{key:'holidaty'},
          contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
          success:data=>{
            let processDefinitionList = $("#process-definition-list").empty();
            data.map((e,i)=>{
              processDefinitionList.append('<tr><td>'+(i+1)+'</td><td>'+e.id+'</td><td class="start-instance">'+e.key+'</td><td>'+e.name+'</td><td>'+e.version+'</td></tr>')
            })
            $('.start-instance').on('click',e=>{
              e.stopPropagation();
              e.preventDefault();
              e = $(e.target);
              let key = e.text();
              let users = $('input[name="users"]').val();
              if(!users){return;}
              $.ajax({
                url: 'http://admin:admin@localhost:8080/runtime',
                type: 'POST',
                contentType: 'application/json;charset=UTF-8',
                data: JSON.stringify({key:key,users:users}),
                success: rst=>alert(rst)
              })
            });
          }
        });
      }); break;
      case 'task': show(id, ()=>{
        let assignee = $('input[name="assignee"]').val();
        if(!assignee){return;}
        $.ajax({
          url:'http://admin:admin@localhost:8080/task',
          type:'GET',
          data:{assignee:assignee},
          contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
          success: rst=>{
            let executionTaskList = $('#execution-task-list').empty();
            console.log(rst);
            rst.map((e,i)=>{
              executionTaskList.append('<tr><td>'+(i+1)+'</td><td>'+e.id+'</td><td>'+e.name+'</td><td>'+e.processInstanceId+'</td><td>'+e.executionId+'</td>'+
                '<td><button class="complete">complete</button><button class="invalidate"/>invalidate</td>'+
              '</tr>')
            });
            $('.complete').on('click', e=>{
              e.stopPropagation();
              e.preventDefault();
              let row = $(e.target).parent().parent();
              let taskId = $(row.children()[1]).text();
              let assignee = $('input[name="assignee"]').val();
              $.ajax({
                url: 'http://admin:admin@localhost:8080/task',
                type: 'POST',
                contentType: 'application/json; charset=UTF-8',
                data: JSON.stringify({taskId: taskId,assignee: assignee}),
                success: rst=>{
                  alert(rst);
                  $('a[data-id="task"]').trigger('click');
                } 
              });
            });
            $('.invalidate').on('click', e=>{
              e.stopPropagation();
              e.preventDefault();
              let row = $(e.target).parent().parent();
              let instanceId = $(row.children()[3]).text();
              $.ajax({
                url: 'http://admin:admin@localhost:8080/runtime',
                type: 'DELETE',
                contentType: 'application/json; charset=UTF-8',
                data: JSON.stringify({instanceId: instanceId}),
                success: rst=>{
                  alert(rst);
                  $('a[data-id="task"]').trigger('click');
                }
              })

            });
          }
        })
      }); break;
    }
  });

  

  function show(contentId,call){
    $.each($('.show'),(i,e)=>{
      if((e = $(e)).attr('id') === contentId){
        e.css('display','block');
      }else{
        e.css('display','none');
      }
    });
    call();
  }

  var downloadLink = $('#js-download-diagram');
  var downloadSvgLink = $('#js-download-svg');
  $('#js-save-svg').on('click',e => {
    submit(e);
  });
  $('#task-query').on('click',e=>{
    e.stopPropagation();
    e.preventDefault();
    $('a[data-id="task"]').trigger('click');
  });

  $('.buttons a').click(function(e) {
    if (!$(this).is('.active')) {
      e.preventDefault();
      e.stopPropagation();
    }
  });

  function setEncoded(link, name, data) {
    var encodedData = encodeURIComponent(data);

    if (data) {
      link.addClass('active').attr({
        'href': 'data:application/bpmn20-xml;charset=UTF-8,' + encodedData,
        'download': name
      });
    } else {
      link.removeClass('active');
    }
  }

  var exportArtifacts = debounce(function() {

    saveSVG(function(err, svg) {
      setEncoded(downloadSvgLink, 'diagram.svg', err ? null : svg);
    });

    download(function(err, xml) {
      setEncoded(downloadLink, 'diagram.bpmn', err ? null : xml);
    });
  }, 500);

  bpmnModeler.on('commandStack.changed', exportArtifacts);
});


